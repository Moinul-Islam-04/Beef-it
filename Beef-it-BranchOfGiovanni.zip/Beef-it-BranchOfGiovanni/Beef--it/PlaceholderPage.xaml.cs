namespace Beef__it;

public partial class PlaceholderPage : ContentPage
{
	public PlaceholderPage()
	{
		InitializeComponent();
	}
}