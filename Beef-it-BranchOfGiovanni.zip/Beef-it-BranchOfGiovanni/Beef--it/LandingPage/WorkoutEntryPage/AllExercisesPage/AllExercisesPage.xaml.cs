using Microsoft.Maui.Controls;

namespace Beef__it
{
    public partial class AllExercisesPage : ContentPage
    {
        public AllExercisesPage()
        {
            InitializeComponent();
        }
    }
}
