using Microsoft.Maui.Controls;

namespace Beef__it
{
    public partial class ProgressPicPage : ContentPage
    {
        public ProgressPicPage()
        {
            InitializeComponent();
        }
    }
}
